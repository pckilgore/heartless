# License:

CC BY-SA 3.0
https://creativecommons.org/licenses/by-sa/3.0/deed.en

# Author

Fibonacci : https://commons.wikimedia.org/wiki/User:Fibonacci

# See

https://commons.wikimedia.org/wiki/File:Broken_heart.svg
